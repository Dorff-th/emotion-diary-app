<template>
  <div class="p-4">
    <h1 class="text-xl font-bold">마이페이지</h1>
  </div>
</template>

<script setup>
// 마이페이지 화면
</script>
