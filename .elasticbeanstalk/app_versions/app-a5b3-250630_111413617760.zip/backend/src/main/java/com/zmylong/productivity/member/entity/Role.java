package com.zmylong.productivity.member.entity;

public enum Role {
    USER,
    ADMIN
}

